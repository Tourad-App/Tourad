package com.example.hussienalrubaye.quranonline;

/**
 * Created by hussienalrubaye on 12/22/15.
 */

public class SettingItem {

    public  String Name;
    public  int ImageURL;

    public SettingItem(String Name, int ImageURL){
        this.Name=Name;
        this.ImageURL=ImageURL;
    }
}
