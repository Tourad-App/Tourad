package com.example.hussienalrubaye.quranonline;

/**
 * Created by hussienalrubaye on 12/26/15.
 */
public class ListBeginEndAya {
    public int beginR;
    public int endread ;
}
