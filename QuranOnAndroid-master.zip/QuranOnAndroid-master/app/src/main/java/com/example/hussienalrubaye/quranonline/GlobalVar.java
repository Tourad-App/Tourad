package com.example.hussienalrubaye.quranonline;

/**
 * Created by hussienalrubaye on 2/10/16.
 */
public class GlobalVar {
  //  public static String RecitesName;
    //public static String RecitesAYA;
}
