#quran For Android

Free open source app for Quran listen online The app is on [Google Play](https://play.google.com/store/apps/details?id=com.onlines.quranonlinesapp&hl=en)

![read](https://lh3.googleusercontent.com/sD90RlO9fnpPiMQj_1344SAqcZt4JQprdBR5mRv_iA3JzgPvF29OSVKr_Wxkto_itKoa=h900)


![list](https://lh3.googleusercontent.com/Vpb2pbEQUhU3XqRJzq7M3WSDqa44OD38hUxgIPTzXMzjfPnR6iauPYQ7cpqHTA9GK7Q=h900)